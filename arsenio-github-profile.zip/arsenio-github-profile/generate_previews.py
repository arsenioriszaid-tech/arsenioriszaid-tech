import cairosvg
import os
import glob

svg_dir = "/home/ubuntu/arsenio-github-profile/assets/svg"
preview_dir = "/home/ubuntu/arsenio-github-profile/assets/previews"
os.makedirs(preview_dir, exist_ok=True)

svg_files = sorted(glob.glob(os.path.join(svg_dir, "*.svg")))

for svg_file in svg_files:
    basename = os.path.splitext(os.path.basename(svg_file))[0]
    output_file = os.path.join(preview_dir, f"{basename}.png")
    try:
        cairosvg.svg2png(url=svg_file, write_to=output_file, output_width=800)
        print(f"Generated: {basename}.png")
    except Exception as e:
        print(f"Error with {basename}: {e}")
